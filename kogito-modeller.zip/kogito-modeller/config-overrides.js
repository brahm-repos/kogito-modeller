module.exports = function override(config, env) {
  config.module.rules.push({
    test: /\.js$/,
    enforce: 'pre',
    use: ['source-map-loader'],
    exclude: [
      /node_modules\/@kogito-tooling\/kie-editors-standalone\/dist\/bpmn/,
      /node_modules\/@kogito-tooling\/kie-editors-standalone\/dist\/dmn/
    ]
  });

  return config;
};
