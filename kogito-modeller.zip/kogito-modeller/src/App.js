import React, { useState, useRef } from 'react';
// eslint-disable-next-line
import * as DmnEditor from "@kogito-tooling/kie-editors-standalone/dist/dmn";
// eslint-disable-next-line
import * as BpmnEditor from "@kogito-tooling/kie-editors-standalone/dist/bpmn";

function App() {
  const [currentEditor, setCurrentEditor] = useState(null);
  const [currentFileHandle, setCurrentFileHandle] = useState(null);
  const editorContainerRef = useRef(null);

  const openBpmnEditor = (initialContent = "") => {
    if (currentEditor) {
      currentEditor.close();
    }
    const editor = BpmnEditor.open({
      container: editorContainerRef.current,
      initialContent: Promise.resolve(initialContent),
      readOnly: false,
      resources: new Map()
    });
    setCurrentEditor(editor);
    setCurrentFileHandle(null);
  };

  const openDmnEditor = () => {
    if (currentEditor) {
      currentEditor.close();
    }
    const editor = DmnEditor.open({
      container: editorContainerRef.current,
      initialContent: Promise.resolve(""),
      readOnly: false,
      resources: new Map()
    });
    setCurrentEditor(editor);
    setCurrentFileHandle(null);
  };

  const openFile = async (event) => {
    const file = event.target.files[0];
    if (file) {
      const content = await file.text();
      openBpmnEditor(content);
      setCurrentFileHandle(file);
    }
  };

  const saveFile = async () => {
    if (currentEditor) {
      const content = await currentEditor.getContent();
      if (currentFileHandle) {
        const writable = await currentFileHandle.createWritable();
        await writable.write(content);
        await writable.close();
        alert("File saved successfully.");
      } else {
        const newFileHandle = await window.showSaveFilePicker({
          suggestedName: "diagram.bpmn",
          types: [
            {
              description: "BPMN Files",
              accept: {
                "application/xml": [".bpmn"]
              }
            }
          ]
        });
        const writable = await newFileHandle.createWritable();
        await writable.write(content);
        await writable.close();
        setCurrentFileHandle(newFileHandle);
        alert("File saved successfully.");
      }
    }
  };

  const validateBpmn = async () => {
    if (currentEditor) {
      const content = await currentEditor.getContent();
      const validationResult = await BpmnEditor.validate(content);
      if (validationResult.length === 0) {
        alert("BPMN file is valid.");
      } else {
        alert("BPMN file has validation errors.");
      }
    }
  };

  const closeFile = () => {
    if (currentEditor) {
      currentEditor.close();
      setCurrentEditor(null);
      setCurrentFileHandle(null);
      editorContainerRef.current.innerHTML = "";
    }
  };

  return (
    <div>
      {/* Removed BPMN and DMN buttons */}
      <div>
        <button onClick={() => openBpmnEditor()}>New BPMN File</button>
        <button onClick={() => document.getElementById("file-input").click()}>Open BPMN File</button>
        <button onClick={saveFile}>Save BPMN File</button>
        <button onClick={validateBpmn}>Validate BPMN File</button>
        <button onClick={closeFile}>Close File</button>
        <input type="file" id="file-input" style={{ display: 'none' }} accept=".bpmn" onChange={openFile} />
      </div>
      <div ref={editorContainerRef} style={{ height: '500px', border: '1px solid #ccc', marginTop: '20px' }}></div>
    </div>
  );
}

export default App;